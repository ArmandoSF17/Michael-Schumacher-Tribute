A Pen created at CodePen.io. You can find this one at https://codepen.io/ArmandoSF17/pen/mxNzGP.

 